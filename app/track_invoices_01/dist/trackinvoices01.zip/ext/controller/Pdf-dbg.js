sap.ui.define([
    "sap/m/MessageToast"
], function(MessageToast) {
    'use strict';

    return {
        pdfshow: function(oEvent) {
            this.showSideContent("GeneratedFacet1");
        }
    };
});
